public class Conta {
    public String cpf;
    public String agencia;
    public String especial; 
    public double valorS;
    public double valorD;
    public double saldo;

    public Conta(String cpf, String agencia, String especial, double valorS, double valorD, double saldo) {
        this.cpf = cpf;
        this.agencia = agencia;
        this.especial = especial;
        this.valorS = valorS;
        this.valorD = valorD;
        this.saldo = saldo;
    }

    public double bonificacao() {
        if (especial.equals("es")) {
            return this.saldo * 0.10;        
        } else {
            return this.saldo * 0.05;
        }
    }
    public double saque() {
        if (valorS > 0 && saldo >= valorS) {
            saldo -= valorS;
        }
        return saldo;
    }
    public double deposito() {
        if (valorD > 0) {
            saldo += valorD;
        }
        return saldo;
    }

 
    public void transferencia(Conta destino) {
        if (valorS > 0 && saldo >= valorS) {
            saldo -= valorS;
            destino.saldo += valorS;
        }
    }

    public void mostrar() {
        System.out.println("CPF: " + cpf);
        System.out.println("Agência: " + agencia);
        System.out.println("Especial: " + especial);
        System.out.println("Saldo: " + saldo);
        System.out.println("Saldo com bonificação: " + (saldo + bonificacao()));
        System.out.println("Saldo com deposito: " + deposito());
        System.out.println("Saldo com saque: " + saque());
    }
}
